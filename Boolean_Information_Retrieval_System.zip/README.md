# Boolean Information Retrieval System

## To perform boolean querying :
``$ python main.py``

_To terminate the program send EOF_

## Documentation:
- Made using pdocs3
- Located in _./html_